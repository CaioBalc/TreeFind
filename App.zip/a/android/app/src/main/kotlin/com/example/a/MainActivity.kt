package com.example.a

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
